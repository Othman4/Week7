#!/bin/bash
#runlevel 

#this scrpt will tell you what is your current runlevel 
# it should give you what runlevel you are at

runlevel 

# to change runlevel to a prefered level just type in init and a level  

init 3


